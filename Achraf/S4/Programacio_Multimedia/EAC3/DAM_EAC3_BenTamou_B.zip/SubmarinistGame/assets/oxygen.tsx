<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="oxygen" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="oxygen.png" width="32" height="32"/>
</tileset>
